#set working directory
setwd("~/R/Tana_River_scripts")
#clear all
cat("\014")
# Clear plots
if(!is.null(dev.list())) dev.off()
# Clean workspace
rm(list=ls())

##################################
# Instal/load Packages
##################################

library(readr)
library(ggplot2)
library(grid)
library(gridExtra)
library(dplyr)
library(lubridate)
library(xts)
library(stringr)
library(utilities)
library(jsonlite)
library(ggpubr)
###########################################
# Data
############################################

Githam <- read_csv("assets/data_asset/githam_water.csv", col_names = FALSE)
karuru <- read_csv("assets/data_asset/karuru_water.csv", col_names = FALSE)
df_data <- read_csv("assets/data_asset/Weatherchannelreleventdata1520.csv")

githam <- Githam
Karuru <- karuru
df_data_1 <- df_data

names(githam) <- c("V1","V2","V3")
names(Karuru) <- c("V1","V2","V3")

####################################
# Inital Githam Analysis
######################################

RawData <- githam[1:3]
Clean_data <- RawData[-1,]

githam = Clean_data %>% mutate( discharge =Clean_data$V3) ##Problem

#separate day, month, year into different columns 
Date_date <- githam 

Date_date$Date <- as.Date(Date_date$V1,format="%m/%d/%y", tz = "Africa/Nairobi") #%Y/%m/%d
Final_data <- Date_date %>%
  mutate(date=format(Date, "%d"),month = format(Date, "%m"), year = format(Date, "%Y"))

Final_Data_Githam <- Final_data

Final_Data_Githam1 <- mutate(Final_Data_Githam, POSIX_date = as.POSIXct(Date_date$V1, format="%m/%d/%y %H:%M", tz="Africa/Nairobi"))
Final_Data_Githam1 <- select(Final_Data_Githam1, POSIX_date, discharge)

#daily average in March, April, May
Conclusion1 <- Final_data %>%
  group_by(date,month,year) %>%
  summarise(Average = mean(as.numeric(as.character(discharge)))) 

Conclusion1$md <- paste(Conclusion1$month, Conclusion1$date,sep = "/")
Conclusion2 <- Conclusion1

for (i in (2015:2020)){
  nam <- paste("daymean", i, sep = "")
  print(nam)
  assign(nam,Conclusion2%>%
           filter(year==i))
}
daymean2019$md <- as.factor(daymean2019$md)
daymean2018$md <- as.factor(daymean2018$md)
daymean2017$md <- as.factor(daymean2017$md)
daymean2016$md <- as.factor(daymean2016$md)
daymean2015$md <- as.factor(daymean2015$md)
daymean2020$md <- as.factor(daymean2020$md)

# plot for daily trend from 2015 to 2020 (except for 2017 and 2020)
# plot for daily trend from 2015 to 2020 (except for 2017 and 2020)
plot(daymean2018$md,daymean2018$Average,ylim=c(0.1,0.8),
     main="Water Level change from 2015 to 2019 in Githam",
     xlab="Month/Date",
     ylab="Water Level / m")
lines(daymean2019$md,daymean2019$Average,type="p",pch=20,col="green",xlab="Month/Date",ylab="discharge rate", main="data",ylim=c(0.020,0.055))
lines(daymean2016$md,daymean2016$Average,type="p",pch=16,col="purple",xlab="Month/Date",ylab="discharge rate", main="data")
lines(daymean2018$md,daymean2018$Average,type="p",pch=17,col="blue",xlab="Month/Date",ylab="discharge rate", main="data")
lines(daymean2015$md,daymean2015$Average,type="p",pch=18,col="red",xlab="Month/Date",ylab="discharge rater", main="data")

lines(smooth.spline(daymean2019$Average ~ daymean2019$md, spar = 0.5), 
      col = "darkgreen", lwd = 2)
lines(smooth.spline(daymean2016$Average ~ daymean2016$md, spar = 0.5), 
      col = "purple", lwd = 2)
lines(smooth.spline(daymean2018$Average ~ daymean2018$md, spar = 0.5), 
      col = "darkblue", lwd = 2)
lines(smooth.spline(daymean2015$Average ~ daymean2015$md, spar = 0.5), col = "darkred", lwd = 2,)

legend("topleft",inset=.05,legend=c("2015","2016","2018","2019"), col=c("red","purple",'blue','green'),lty=1, ncol=1,cex=0.75)

####################################
# Inital Karuru Analysis
######################################

RawData <- Karuru[1:3]
Clean_data <- RawData[-1,]

Karuru = Clean_data %>% mutate( discharge =Clean_data$V3) ##Problem

#separate day, month, year into different columns 
Date_date <- Karuru

Date_date$Date <- as.Date(Date_date$V1,format="%Y/%m/%d", tz = "Africa/Nairobi") #%Y/%m/%d
Final_data <- Date_date %>%
  mutate(date=format(Date, "%d"),month = format(Date, "%m"), year = format(Date, "%Y"))

Final_Data_Karuru <- Final_data

Final_Data_Karuru1 <- mutate(Final_Data_Karuru, POSIX_date = as.POSIXct(Date_date$V1,format="%Y/%m/%d %H:%M", tz = "Africa/Nairobi"))
Final_Data_Karuru1 <- select(Final_Data_Karuru1, POSIX_date, discharge)

#daily average in March, April, May
Conclusion1 <- Final_data %>%
  group_by(date,month,year) %>%
  summarise(Average = mean(as.numeric(as.character(discharge))))

Conclusion1$md <- paste(Conclusion1$month, Conclusion1$date,sep = "/")
Conclusion2 <- Conclusion1

for (i in (2015:2020)){
  nam <- paste("daymean", i, sep = "")
  print(nam)
  assign(nam,Conclusion2%>%
           filter(year==i))
}
daymean2019$md <- as.factor(daymean2019$md)
daymean2018$md <- as.factor(daymean2018$md)
daymean2017$md <- as.factor(daymean2017$md)
daymean2016$md <- as.factor(daymean2016$md)
daymean2015$md <- as.factor(daymean2015$md)
daymean2020$md <- as.factor(daymean2020$md)

# plot for daily trend from 2015 to 2020 (except for 2017 and 2020)
# plot for daily trend from 2015 to 2020 (except for 2017 and 2020)
plot(daymean2018$md,daymean2018$Average,ylim=c(0.24,1.25),
     main="Water Level change from 2015 to 2019 in Karurumo",
     xlab="Month/Date",
     ylab="Water Level / m")
lines(daymean2019$md,daymean2019$Average,type="p",pch=20,col="green",xlab="Month/Date",ylab="discharge rate", main="data",ylim=c(0.020,0.055))
lines(daymean2016$md,daymean2016$Average,type="p",pch=16,col="purple",xlab="Month/Date",ylab="discharge rate", main="data")
lines(daymean2018$md,daymean2018$Average,type="p",pch=17,col="blue",xlab="Month/Date",ylab="discharge rate", main="data")
lines(daymean2015$md,daymean2015$Average,type="p",pch=18,col="red",xlab="Month/Date",ylab="discharge rater", main="data")

lines(smooth.spline(daymean2019$Average ~ daymean2019$md, spar = 0.5), 
      col = "darkgreen", lwd = 2)
lines(smooth.spline(daymean2016$Average ~ daymean2016$md, spar = 0.5), 
      col = "purple", lwd = 2)
lines(smooth.spline(daymean2018$Average ~ daymean2018$md, spar = 0.5), 
      col = "darkblue", lwd = 2)
lines(smooth.spline(daymean2015$Average ~ daymean2015$md, spar = 0.5), col = "darkred", lwd = 2,)

legend("topleft",inset=.05,legend=c("2015","2016","2018","2019"), col=c("red","purple",'blue','green'),lty=1, ncol=1,cex=0.75)

###################################
# Stats Analysis clean data
#####################################

# filter out data so only discharge and month remain
Final_Data_Githam <- select(Final_Data_Githam, discharge, month)
Final_Data_Karuru <- select(Final_Data_Karuru, discharge, month)

#convert month from character to number
Final_Data_Githam <- mutate(Final_Data_Githam, Month = as.numeric(Final_Data_Githam$month))
Final_Data_Karuru <- mutate(Final_Data_Karuru, Month = as.numeric(Final_Data_Karuru$month))

#remove unnecessary character month column
Final_Data_Githam <- select(Final_Data_Githam, -month)
Final_Data_Karuru <- select(Final_Data_Karuru, -month)

# create a new column that classifies if the month is in the rainy season or dry season
Final_Data_Githam <- mutate(Final_Data_Githam, Season = ifelse(Month == 1 | Month ==3| Month ==4| Month ==5|Month ==10|Month ==11|Month ==12, "Rainy_Season_Githam","Dry_Season_Githam" ))
Final_Data_Karuru <- mutate(Final_Data_Karuru, Season = ifelse(Month == 1 | Month ==3| Month ==4| Month ==5|Month ==10|Month ==11|Month ==12, "Rainy_Season_Karuru","Dry_Season_Karuru" ))

#Remove month coulmn
Final_Data_Githam <- select(Final_Data_Githam, -Month)
Final_Data_Karuru <- select(Final_Data_Karuru, -Month)

#convert Discharge from factor to number
Final_Data_Githam <- mutate(Final_Data_Githam, Discharge = as.numeric(as.character(Final_Data_Githam$discharge)))
Final_Data_Karuru <- mutate(Final_Data_Karuru, Discharge = as.numeric(as.character(Final_Data_Karuru$discharge)))

#Remove factor discharge column

Final_Data_Githam <- select(Final_Data_Githam, -discharge)
Final_Data_Karuru <- select(Final_Data_Karuru, -discharge)

#stack rows on top of one another for ANOVA Analysis

Githam_Karuru_stacked <- bind_rows(Final_Data_Githam,Final_Data_Karuru)

#sort dataframe by Season column

Githam_Karuru_stacked <- Githam_Karuru_stacked %>% arrange(Season)

#create table with mean discharge for all four categories
Githam_Karuru_mean <- group_by(Githam_Karuru_stacked, Season)
Githam_Karuru_mean <- summarise(Githam_Karuru_mean, Avg_discharge = mean(Discharge))
Githam_Karuru_mean <- ungroup(Githam_Karuru_mean)

#######################################
# Boxplot visual
#######################################

ggplot(Githam_Karuru_stacked , aes(x =Season, y = Discharge, fill = Season))+
  geom_point(aes(size = Discharge))+
  geom_boxplot(alpha = .7, outlier.colour = NA)+
  scale_fill_discrete(labels= c("Githambara(T) Dry","Karurumo(C) Dry","Githambara(T) Wet","Karurumo(C) Wet"))+
  labs(title = "Boxplot of Seasonal Water Level In Githambara and Karurumo" ,  y = "Water Level(m)", x = "Season")+
  scale_x_discrete(labels=c("Githambara Dry","Karurumo Dry","Githambara Wet","Karurumo Wet")) +
  theme_bw()

ggsave("C:/Users/Liam Maxwell/Documents/R/Tana_River_scripts/Githam_Karurumo_boxplots.jpeg")

#########################################
# ANOVA test
#########################################

# ANOVA Test

Githam_Karuru_ANOVA <- aov(formula = Discharge ~ Season, data = Githam_Karuru_stacked)
summary(Githam_Karuru_ANOVA)

###########################################
# Individual t-tests
############################################

# t-test Rainy Season between Githam and Karuru 


#create appropriate data table
Rainy_season <- filter(Githam_Karuru_stacked, str_length(Githam_Karuru_stacked$Season) == 19)


Rainy_Ttest <- t.test(Discharge ~ Season, data = Rainy_season, mu = 0, conf = .95, var.eq = FALSE, paired = FALSE)
Rainy_Ttest

# t-test dry Season between Githam and Karuru 

#create appropriate data table
Dry_season <- filter(Githam_Karuru_stacked, str_length(Githam_Karuru_stacked$Season) == 17)

Dry_Ttest <- t.test(Discharge ~ Season, data = Dry_season, mu = 0, conf = .95, var.eq = FALSE, paired = FALSE)
Dry_Ttest

# t-test Githam between Rainy and Dry seasons 

Githam_Ttest <- t.test(Discharge ~ Season, data = Final_Data_Githam, mu = 0, conf = .95, var.eq = FALSE, paired = FALSE)
Githam_Ttest

# t-test Githam between Rainy and Dry seasons 

Karuru_Ttest <- t.test(Discharge ~ Season, data = Final_Data_Karuru, mu = 0, conf = .95, var.eq = FALSE, paired = FALSE)
Karuru_Ttest

###############################################
# Rain vs. Water Level plot Githam
################################################

#convert date from factor to string
df_data_1 <- mutate(df_data_1, Date = as.character(df_data_1$observationTimeUtcIso))

#remove factor date column
df_data_1 <- select(df_data_1, -observationTimeUtcIso)

#'2015-01-01T00:00:00+0000'
date_string <- "([0-9]{4}[-][0-9]{2}[-][0-9]{2}[T][0-9]{2}[:][0-9]{2}[: ;]*[0-9]{2}[+][0]{4})"

# Clean date string so that it can be converted into a date
df_data_1 <- mutate(df_data_1, Date1 = str_replace(df_data_1$Date, "([+][0]{4})", ""))
df_data_1 <- mutate(df_data_1, Date2 = str_replace(df_data_1$Date1, "[T]", " "))

#remove unnessarry columns
df_data_1 <- select(df_data_1, -Date, -Date1)

#2015-01-01 00:00:00
df_data_1 <- mutate(df_data_1, POSIX_date = as.POSIXct(df_data_1$Date2, format="%Y-%m-%d %H:%M:%S", tz = "Africa/Nairobi"))

#filter lat
Githam_weather <- filter(df_data_1, latitude < -0.78)
Githam_weather <- filter(Githam_weather, latitude > -0.83)
# Join weather data and discharge data
#  full_join(DATAFILE1, DATAFILE2, by = MATCHVAR).
Githam_join <- full_join(Githam_weather, Final_Data_Githam1, by = "POSIX_date")

# omit na values
Githam_join <- na.omit(Githam_join)

#change discharge factor to numeric
Githam_join <- mutate(Githam_join, discharge1 = as.numeric(as.character(Githam_join$discharge)))
Githam_join <- select(Githam_join, -discharge)

#Average rainfall and discharge for same date across multiple locations
Githam_join <- group_by(Githam_join, POSIX_date)
Githam_rain_discharge <- summarise(Githam_join, Avg_discharge = mean(discharge1), Avg_rain = mean(precipitationRate), Avg_temp = mean(temperature), Avg_windspeed = mean(windSpeed))
Githam_join <- ungroup(Githam_join)


#plot time vs discharge vs rainfall
ggplot(Githam_rain_discharge, aes(x=POSIX_date)) + 
  geom_line(aes(y = Avg_discharge, color = "red")) +
  geom_point(aes(y=Avg_rain, color = "blue"))+ 
  labs(x = "Date")

#new variable for daily averaged discharge/precipitation
Githam_daily_avg <- Githam_rain_discharge
#add new variable of just the date (no time component)
Githam_daily_avg <- mutate(Githam_daily_avg, New_date = as.POSIXct(format(Githam_daily_avg$POSIX_date, format = "%Y-%m-%d")), format = "%Y-%m-%d")
#remove unnecessary columns
Githam_daily_avg <- select(Githam_daily_avg, -POSIX_date)
#group by date column
Githam_daily_avg <- group_by(Githam_daily_avg, New_date)
#calculate daily averaged precipitation and discharge
Githam_daily_average <- summarise(Githam_daily_avg, avg_discharge = mean(Avg_discharge), avg_rain = mean(Avg_rain))
#ungroup
Githam_daily_avg <- ungroup(Githam_daily_avg)

#plot daily averaged time vs discharge vs rainfall
ggplot() + 
  geom_point(data = Githam_daily_average, aes(x=New_date, y=avg_rain, color = "red"))+
  geom_line(data = Githam_daily_average, aes(x=New_date, y=avg_discharge, color = "blue")) +
  scale_colour_discrete(name = "", labels = c("Water Level","Precipitation Rate")) +
  theme_bw()+
  scale_y_continuous(
    
    # Features of the first axis
    name = "Precipitation Rate (mm/s)", 
    
    # Add a second axis and specify its features
    sec.axis = sec_axis(~.*1, name="Water Level (m)")
  ) + 
  theme(
    axis.title.y = element_text(color = "blue", size=13),
    axis.title.y.right = element_text(color = "red", size=13)
    )+
  labs(x = "Date", title = "Daily Averaged Precipitation and Water Level, Githambara Watershed")
  
#theme(legend.position = c(0.20, 0.75)) 
  #theme(panel.background = element_rect(fill="white"))
  
ggsave("C:/Users/Liam Maxwell/Documents/R/Tana_River_scripts/Githam_daily_avg_waterlevel_Precipitation.jpeg")

###############################################
# Rain vs. Water Level plot Karurumo
################################################

#filter lat
Karuru_weather <- filter(df_data_1, latitude < -0.78)
Karuru_weather <- filter(Githam_weather, latitude > -0.83)
# Join weather data and discharge data
#  full_join(DATAFILE1, DATAFILE2, by = MATCHVAR).
Karuru_join <- full_join(Karuru_weather, Final_Data_Karuru1, by = "POSIX_date")

# omit na values
Karuru_join <- na.omit(Karuru_join)

#change discharge factor to numeric
Karuru_join <- mutate(Karuru_join, discharge1 = as.numeric(as.character(Karuru_join$discharge)))
Karuru_join <- select(Karuru_join, -discharge)

#Average rainfall and discharge for same date across multiple locations
Karuru_join <- group_by(Karuru_join, POSIX_date)
Karuru_rain_discharge <- summarise(Karuru_join, Avg_discharge = mean(discharge1), Avg_rain = mean(precipitationRate),Avg_temp = mean(temperature), Avg_windspeed = mean(windSpeed))
Karuru_join <- ungroup(Karuru_join)


#plot time vs discharge vs rainfall
ggplot(Karuru_rain_discharge, aes(x=POSIX_date)) + 
  geom_line(aes(y = Avg_discharge, color = "red")) +
  geom_point(aes(y=Avg_rain, color = "blue"))+ 
  labs(x = "Date")

#new variable for daily averaged discharge/precipitation
Karuru_daily_avg <- Karuru_rain_discharge
#add new variable of just the date (no time component)
Karuru_daily_avg <- mutate(Karuru_daily_avg, New_date = as.POSIXct(format(Karuru_daily_avg$POSIX_date, format = "%Y-%m-%d")), format = "%Y-%m-%d")
#remove unnecessary columns
Karuru_daily_avg <- select(Karuru_daily_avg, -POSIX_date)
#group by date column
Karuru_daily_avg <- group_by(Karuru_daily_avg, New_date)
#calculate daily averaged precipitation and discharge
Karuru_daily_average <- summarise(Karuru_daily_avg, avg_discharge = mean(Avg_discharge), avg_rain = mean(Avg_rain))
#ungroup
Karuru_daily_avg <- ungroup(Karuru_daily_avg)

#plot daily averaged time vs discharge vs rainfall
ggplot() + 
  geom_point(data = Karuru_daily_average, aes(x=New_date, y=avg_rain, color = "red"))+
  geom_line(data = Karuru_daily_average, aes(x=New_date, y=avg_discharge, color = "blue")) +
  scale_colour_discrete(name = "", labels = c("Water Level","Precipitation Rate")) +
  theme_bw()+
  scale_y_continuous(
    
    # Features of the first axis
    name = "Precipitation Rate (units)", 
    
    # Add a second axis and specify its features
    sec.axis = sec_axis(~.*1, name="Water Level (m)")
  ) + 
  theme(
    axis.title.y = element_text(color = "blue", size=13),
    axis.title.y.right = element_text(color = "red", size=13)
  )+
  labs(x = "Date", title = "Daily Averaged Precipitation and Water Level, Karurumo Watershed")
  
  #theme(legend.position = c(0.20, 0.75)) +
  #theme(panel.background = element_rect(fill="white"))

ggsave("C:/Users/Liam Maxwell/Documents/R/Tana_River_scripts/Karuru_daily_avg_waterlevel_Precipitation.jpeg")

##########################################
# Multivariable linear regression analysis
##########################################

#add marker variables


Githam_join_new <- Githam_rain_discharge %>%
  mutate(Month = as.numeric(format(POSIX_date, "%m")))
Githam_join_new <- mutate(Githam_join_new, Season = ifelse(Month == 1 | Month ==3| Month ==4| Month ==5|Month ==10|Month ==11|Month ==12, "Rainy_Season_Githam","Dry_Season_Githam" ))
Githam_join_new <- Githam_join_new %>% arrange(Season)
Githam_join_new <- mutate(Githam_join_new, Marker_num = 1)
#Githam_join_new <- select(Githam_join_new, temperature, windSpeed, precipitationRate, Season, discharge1, POSIX_date)
Githam_dry <- Githam_join_new[1:8782, ]
Githam_wet <- Githam_join_new[8783:20414, ]
#8782

Karuru_join_new <- Karuru_rain_discharge %>%
  mutate(Month = as.numeric(format(POSIX_date, "%m")))
Karuru_join_new <- mutate(Karuru_join_new, Season = ifelse(Month == 1 | Month ==3| Month ==4| Month ==5|Month ==10|Month ==11|Month ==12, "Rainy_Season_Karuru","Dry_Season_Karuru" ))
Karuru_join_new <- Karuru_join_new %>% arrange(Season)
Karuru_join_new <- mutate(Karuru_join_new, Marker_num = 0)
#Karuru_join_new <- select(Karuru_join_new, temperature, windSpeed, precipitationRate, Season, discharge1, POSIX_date)
Karuru_dry <- Karuru_join_new[1:10257, ]
Karuru_wet <- Karuru_join_new[10258:24002, ]
#10257

#join datasets and remove uneccessary variables

#Multi_linear_reg <- bind_rows(Githam_join, Karuru_join)
#Multi_linear_reg <- select(Multi_linear_reg, temperature, windSpeed, precipitationRate, POSIX_date, discharge1, Marker, Marker_num)

#########################
#Scatterplots Githam
#########################

Gith_scat <- ggscatter(Githam_join_new, x="Avg_rain", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Precipitation [mm/s]", ylab = "Water Level[m]",
          title = "Precipitation vs. Water Level")+
          theme_bw()

Gith_scat_wet <- ggscatter(Githam_wet, x="Avg_rain", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Precipitation [mm/s]", ylab = "Water Level[m]",
          title = "Precipitation vs. Water Level Wet Seasons")+
          theme_bw()

Gith_scat_dry <- ggscatter(Githam_dry, x="Avg_rain", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Precipitation [mm/s]", ylab = "Water Level[m]",
          title = "Precipitation vs. Water Level Dry Season")+
          theme_bw()


#########################
#Scatterplots Karuru
#########################

#Karuru total
Karu_scat <- ggscatter(Karuru_join_new, x="Avg_rain", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Precipitation", ylab = "Water Level",
          title = "Precipitation vs. Water Level")+
  theme_bw()
#Karuru Wet Season
Karu_scat_wet <- ggscatter(Karuru_wet, x="Avg_rain", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Precipitation", ylab = "Water Level",
          title = "Precipitation vs. Water Level Wet Season")+
  theme_bw()
#Karuru Dry Season
Karu_scat_dry <- ggscatter(Karuru_dry, x="Avg_rain", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Precipitation", ylab = "Water Level",
          title = "Precipitation vs. Water Level Dry Season")+
  theme_bw()

Karur_dry_LinReg <- lm(Karuru_dry$Avg_discharge ~ Karuru_dry$Avg_rain)
#plot(Karur_dry_LinReg)
Karur_dry_LinReg$coefficients
######################################
# Clump Rain into weekly total Githam
######################################
n <- 0
Githam_rain_clump <- Githam_join_new[7:length(Githam_join_new$POSIX_date), ]
for (k in 1:length(Githam_join_new$POSIX_date)) {
  if(k > 6){
    n <- n+1
    Githam_rain_clump[n,ncol(Githam_join_new)+1] <- sum(Githam_join_new[k,3],Githam_join_new[k-1,3],Githam_join_new[k-2,3],Githam_join_new[k-3,3],Githam_join_new[k-4,3],Githam_join_new[k-5,3],Githam_join_new[k-6,3])
  }
}
names(Githam_rain_clump)[ncol(Githam_join_new)+1] <- "Rain_clump"

Gith_scat_clump <- ggscatter(Githam_rain_clump, x="Rain_clump", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Precipitation Past week summed[mm/s]", ylab = "Water Level[m]",
          title = "Precipitation vs. Water Level")+
          theme_bw()


##########################################
# Clump Rain into weekly total wet Githam
##########################################

Githam_wet <- Githam_wet %>% arrange(POSIX_date)

n <- 0
Githam_rain_clump_wet <- Githam_wet[7:length(Githam_wet$POSIX_date), ]
for (k in 1:length(Githam_wet$POSIX_date)) {
  if(k > 6){
    n <- n+1
    Githam_rain_clump_wet[n,ncol(Githam_wet)+1] <- sum(Githam_wet[k,3],Githam_wet[k-1,3],Githam_wet[k-2,3],Githam_wet[k-3,3],Githam_wet[k-4,3],Githam_wet[k-5,3],Githam_wet[k-6,3])
  }
}
names(Githam_rain_clump_wet)[ncol(Githam_wet)+1] <- "Rain_clump"

Gith_scat_wet_clump <- ggscatter(Githam_rain_clump_wet, x="Rain_clump", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Precipitation Past week summed[mm/s]", ylab = "Water Level[m]",
          title = "Precipitation vs. Water Level Wet Seasons ")+
          theme_bw()
          


#########################################
# Clump Rain into weekly total dry Githam
########################################

Githam_dry <- Githam_dry %>% arrange(POSIX_date)

n <- 0
Githam_rain_clump_dry <- Githam_dry[7:length(Githam_dry$POSIX_date), ]
for (k in 1:length(Githam_dry$POSIX_date)) {
  if(k > 6){
    n <- n+1
    Githam_rain_clump_dry[n,ncol(Githam_dry)+1] <- sum(Githam_dry[k,3],Githam_dry[k-1,3],Githam_dry[k-2,3],Githam_dry[k-3,3],Githam_dry[k-4,3],Githam_dry[k-5,3],Githam_dry[k-6,3])
  }
}
names(Githam_rain_clump_dry)[ncol(Githam_dry)+1] <- "Rain_clump"

Gith_scat_dry_clump <- ggscatter(Githam_rain_clump_dry, x="Rain_clump", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Precipitation Past week summed[mm/s]", ylab = "Water Level[m]",
          title = "Precipitation vs. Water Level Dry Season ")+
          theme_bw()

grid.arrange(Gith_scat,Gith_scat_wet,Gith_scat_dry,Gith_scat_clump,Gith_scat_wet_clump,Gith_scat_dry_clump, nrow = 2,ncol = 3, 
                  top = textGrob("Githambara",gp=gpar(fontsize=20,font=3)))

######################################
# Clump Rain into weekly total Karuru
######################################
n <- 0
Karuru_rain_clump <- Karuru_join_new[7:length(Karuru_join_new$POSIX_date), ]
for (k in 1:length(Karuru_join_new$POSIX_date)) {
  if(k > 6){
    n <- n+1
    Karuru_rain_clump[n,ncol(Karuru_join_new)+1] <- sum(Karuru_join_new[k,3],Karuru_join_new[k-1,3],Karuru_join_new[k-2,3],Karuru_join_new[k-3,3],Karuru_join_new[k-4,3],Karuru_join_new[k-5,3],Karuru_join_new[k-6,3])
  }
}
names(Karuru_rain_clump)[ncol(Karuru_join_new)+1] <- "Rain_clump"

Karu_scat_clump <- ggscatter(Karuru_rain_clump, x="Rain_clump", y="Avg_discharge",
                             add = "reg.line", conf.int = TRUE, 
                             cor.coef = TRUE, cor.method = "pearson",
                             xlab = "Precipitation Past week summed[mm/s]", ylab = "Water Level[m]",
                             title = "Precipitation vs. Water Level")+
  theme_bw()


##########################################
# Clump Rain into weekly total wet Karuru
##########################################

Karuru_wet <- Karuru_wet %>% arrange(POSIX_date)

n <- 0
Karuru_rain_clump_wet <- Karuru_wet[7:length(Karuru_wet$POSIX_date), ]
for (k in 1:length(Karuru_wet$POSIX_date)) {
  if(k > 6){
    n <- n+1
    Karuru_rain_clump_wet[n,ncol(Karuru_wet)+1] <- sum(Karuru_wet[k,3],Karuru_wet[k-1,3],Karuru_wet[k-2,3],Karuru_wet[k-3,3],Karuru_wet[k-4,3],Karuru_wet[k-5,3],Karuru_wet[k-6,3])
  }
}
names(Karuru_rain_clump_wet)[ncol(Karuru_wet)+1] <- "Rain_clump"

Karu_scat_wet_clump <- ggscatter(Karuru_rain_clump_wet, x="Rain_clump", y="Avg_discharge",
                                 add = "reg.line", conf.int = TRUE, 
                                 cor.coef = TRUE, cor.method = "pearson",
                                 xlab = "Precipitation Past week summed[mm/s]", ylab = "Water Level[m]",
                                 title = "Precipitation vs. Water Level Wet Seasons ")+
  theme_bw()



#########################################
# Clump Rain into weekly total dry Githam
########################################

Karuru_dry <- Karuru_dry %>% arrange(POSIX_date)

n <- 0
Karuru_rain_clump_dry <- Karuru_dry[7:length(Karuru_dry$POSIX_date), ]
for (k in 1:length(Karuru_dry$POSIX_date)) {
  if(k > 6){
    n <- n+1
    Karuru_rain_clump_dry[n,ncol(Karuru_dry)+1] <- sum(Karuru_dry[k,3],Karuru_dry[k-1,3],Karuru_dry[k-2,3],Karuru_dry[k-3,3],Karuru_dry[k-4,3],Karuru_dry[k-5,3],Karuru_dry[k-6,3])
  }
}
names(Karuru_rain_clump_dry)[ncol(Karuru_dry)+1] <- "Rain_clump"

Karu_scat_dry_clump <- ggscatter(Karuru_rain_clump_dry, x="Rain_clump", y="Avg_discharge",
                                 add = "reg.line", conf.int = TRUE, 
                                 cor.coef = TRUE, cor.method = "pearson",
                                 xlab = "Precipitation Past week summed[mm/s]", ylab = "Water Level[m]",
                                 title = "Precipitation vs. Water Level Dry Season ")+
  theme_bw()

grid.arrange(Karu_scat,Karu_scat_wet,Karu_scat_dry,Karu_scat_clump,Karu_scat_wet_clump,Karu_scat_dry_clump, nrow = 2,ncol = 3, 
             top = textGrob("Karurumo",gp=gpar(fontsize=20,font=3)))

###############################################
#Scatterplot Githam Temp
###############################################

Gith_temp <- ggscatter(Githam_join_new, x="Avg_temp", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Temperature [C]", ylab = "Water Level[m]",
          title = "Githambara")+
  theme_bw()

Gith_wet_temp <- ggscatter(Githam_wet, x="Avg_temp", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Temperature [C]", ylab = "Water Level[m]",
          title = "Githambara Wet Season")+
  theme_bw()

Gith_dry_temp<- ggscatter(Githam_dry, x="Avg_temp", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Temperature [C]", ylab = "Water Level[m]",
          title = "Githambara Dry Season")+
  theme_bw()


###############################################
#Scatterplot Karuru Temp
###############################################

Karu_temp <- ggscatter(Karuru_join_new, x="Avg_temp", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Temperature [C]", ylab = "Water Level[m]",
          title = "Karurmo")+
  theme_bw()

Karu_wet_temp <- ggscatter(Karuru_wet, x="Avg_temp", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Temperature [C]", ylab = "Water Level[m]",
          title = "Karurmo Wet Season")+
  theme_bw()

Karu_dry_temp <- ggscatter(Karuru_dry, x="Avg_temp", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Temperature [C]", ylab = "Water Level[m]",
          title = "Karurumo Dry Season")+
  theme_bw()

grid.arrange(Gith_temp, Gith_wet_temp, Gith_dry_temp, Karu_temp, Karu_wet_temp, Karu_dry_temp, nrow = 2,ncol = 3, 
             top = textGrob("Temperature Vs. Water Level",gp=gpar(fontsize=20,font=3)))
###############################################
#Scatterplot Githam Windspeed
###############################################


Gith_wind <- ggscatter(Githam_join_new, x="Avg_windspeed", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Windspeed", ylab = "Water Level[m]",
          title = "Githambara")+
  theme_bw()

Gith_wet_wind <- ggscatter(Githam_wet, x="Avg_windspeed", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Windspeed", ylab = "Water Level[m]",
          title = "Githambara Wet Season")+
  theme_bw()

Gith_dry_wind <- ggscatter(Githam_dry, x="Avg_windspeed", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Windspeed", ylab = "Water Level[m]",
          title = "Githambara Dry Season")+
  theme_bw()

###############################################
#Scatterplot Karuru Windspeed
###############################################


Karu_wind <- ggscatter(Karuru_join_new, x="Avg_windspeed", y="Avg_discharge",
                       add = "reg.line", conf.int = TRUE, 
                       cor.coef = TRUE, cor.method = "pearson",
                       xlab = "Windspeed", ylab = "Water Level[m]",
                       title = "Karurumo")+
  theme_bw()

Karu_wet_wind <- ggscatter(Karuru_wet, x="Avg_windspeed", y="Avg_discharge",
                           add = "reg.line", conf.int = TRUE, 
                           cor.coef = TRUE, cor.method = "pearson",
                           xlab = "Windspeed", ylab = "Water Level[m]",
                           title = "Karurumo Wet Season")+
  theme_bw()

Karu_dry_wind <- ggscatter(Karuru_dry, x="Avg_windspeed", y="Avg_discharge",
                           add = "reg.line", conf.int = TRUE, 
                           cor.coef = TRUE, cor.method = "pearson",
                           xlab = "Windspeed", ylab = "Water Level[m]",
                           title = "Karurumo Dry Season")+
  theme_bw()

grid.arrange(Gith_wind, Gith_wet_wind, Gith_dry_wind, Karu_wind, Karu_wet_wind, Karu_dry_wind, nrow = 2,ncol = 3, 
             top = textGrob("Wind Speed Vs. Water Level",gp=gpar(fontsize=20,font=3)))

######################################
# Clump Rain into weekly total Karuru
######################################
n <- 0
Karuru_rain_clump <- Karuru_join_new[7:length(Karuru_join_new$POSIX_date), ]
for (k in 1:length(Karuru_join_new$POSIX_date)) {
  if(k > 6){
    n <- n+1
    Karuru_rain_clump[n,ncol(Karuru_join_new)+1] <- sum(Karuru_join_new[k,3],Karuru_join_new[k-1,3],Karuru_join_new[k-2,3],Karuru_join_new[k-3,3],Karuru_join_new[k-4,3],Karuru_join_new[k-5,3],Karuru_join_new[k-6,3])
  }
}
names(Karuru_rain_clump)[ncol(Karuru_join_new)+1] <- "Rain_clump"

ggscatter(Karuru_rain_clump, x="Rain_clump", y="Avg_discharge",
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Precipitation Past week summed", ylab = "Water Level",
          title = "Precipitation vs. Water Level Karuru")

####################################
#Multi-Variable Analysis
####################################

MultiVar_Rain_Loc <- bind_rows(select(Githam_rain_clump, Season, Marker_num, Avg_discharge, Rain_clump), select(Karuru_rain_clump, Season, Marker_num, Avg_discharge, Rain_clump)) 


ggplot(data = Githam_rain_clump, aes(x=Rain_clump, y=Avg_discharge)) + 
  geom_point(color = "red", alpha = .8)+
  geom_smooth(method = "lm",color = "red")+
  geom_point(data = Karuru_rain_clump, aes(x=Rain_clump, y=Avg_discharge), color = "yellow", alpha = 0.5) +
  geom_smooth(data = Karuru_rain_clump, aes(x=Rain_clump, y=Avg_discharge), color = "yellow", method = "lm")+
  scale_color_manual(name = "", breaks = c("red","yellow") ,values = c("red","yellow")) +
  #scale_color_discrete(name = "",labels = c("Githam","Karuru")) +
  labs(x = "Weekly Summed Precipitation", y = "Water Level (m)", title= "Precipitation vs Water Level in Githam and Karuru")+
  theme_bw()

ggsave("C:/Users/Liam Maxwell/Documents/R/Tana_River_scripts/Karuru_Githam_Precip_vs_WaterLevel.jpeg")
  
  #theme(legend.position = c(0.75, 0.75)) +
  #theme(panel.background = element_rect(fill="white"))

############################################
#Multi-Variable Linear Model Results
############################################

# Multivariable linear regression to see location and precipitations effect on water level
Multivariable_LM_model <- lm(formula = Avg_discharge ~ Rain_clump + Marker_num, data = MultiVar_Rain_Loc)
summary(Multivariable_LM_model)
#cor(MultiVar_Rain_Loc$Rain_clump, MultiVar_Rain_Loc$Marker_num, methods = "pearson")


# just watershed variable

Multivariable_LM_model <- lm(formula = Avg_discharge ~ Marker_num, data = MultiVar_Rain_Loc)
summary(Multivariable_LM_model)

ggplot(data = MultiVar_Rain_Loc, aes(x=Marker_num, y=Avg_discharge))+
  geom_point()


###############################33
#Trial Plot
################################


#ggplot(data = MultiVar_Rain_Loc, aes(x=Rain_clump, y=Avg_discharge))+
#  geom_point(aes(color = Season))+
#  geom_smooth(method = "lm")+
#  facet_wrap("Season")